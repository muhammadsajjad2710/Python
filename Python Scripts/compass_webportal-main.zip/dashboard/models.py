from django.contrib.auth.models import AbstractUser
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver







# Overriding the Default Django Auth User and adding One More Field (user_type)
class CustomUser(AbstractUser):
    user_type_data = ((1, "HOD"), (2, "Staff"), (3, "Student"))
    user_type = models.CharField(default=1, choices=user_type_data, max_length=10)



class AdminHOD(models.Model):
    id = models.AutoField(primary_key=True)
    admin = models.OneToOneField(CustomUser, on_delete = models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()


class Staffs(models.Model):
    id = models.AutoField(primary_key=True)
    admin = models.OneToOneField(CustomUser, on_delete = models.CASCADE)
    address = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()








class Contract(models.Model):
    id = models.AutoField(primary_key=True)
    Contract_ID = models.FloatField(null=True)
    Commissioner = models.CharField(max_length=500, null=True)
    ContractType = models.CharField(max_length=200, null=True)
    Start_Date = models.DateTimeField(null=True)
    End_Date = models.DateTimeField(null=True)
    Status = models.CharField(max_length=200, null=True)
    Contract_UDAs = models.IntegerField(null=True)  

    class Meta:
        db_table = 'contract_id'





class Performer(models.Model):
    id = models.AutoField(primary_key=True)
    Performer_ID = models.IntegerField(unique=True)
    Surname = models.CharField(max_length=50)
    Forename = models.CharField(max_length=50)
    GDC_Number = models.IntegerField()

    class Meta:
        db_table = 'Performers'




    def __str__(self):
        return self.Contract_Name  # Display Contract Name in admin panel




class DataReport(models.Model):
    id = models.AutoField(primary_key=True)
    CRN_IN = models.CharField(max_length=50)
    ContractID = models.CharField(max_length=50, null=True)
    PerformerID = models.CharField(max_length=50, null=True)
    Errors = models.CharField(max_length=50, null=True)
    PatientSurname = models.CharField(max_length=50, null=True)
    PatientForename = models.CharField(max_length=50, null=True)
    DateOfBirth = models.DateTimeField(null=True)
    TreatmentStartDate = models.DateTimeField(null=True)
    TreatmentEndDate = models.DateTimeField(null=True)
    PatientCharge = models.CharField(max_length=50, null=True)
    Period = models.CharField(max_length=50, null=True)
    Units = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    ContraPeriod_Units_PCharge = models.CharField(max_length=50, null=True)
    NHSNumber = models.CharField(max_length=50, null=True)
    ProcessingDate = models.DateTimeField(null=True)
    Status = models.CharField(max_length=50, null=True)
    FormType = models.CharField(max_length=50, null=True)
    CreatedAmendedDeletedby =models.CharField(max_length=50, null=True)
    CreationAmendDeletionDate = models.DateTimeField(null=True)

    class Meta:
        db_table = 'data_report'


class ContractedUDAsDetails(models.Model):
    id = models.AutoField(primary_key=True)
    contract_id = models.CharField(max_length=255)
    contracted_udas = models.CharField(max_length=255)
    carry_over_udas = models.CharField(max_length=255, default='default_value')
    def __str__(self):
        return f"{self.contract_id} - {self.contracted_udas}"


#Creating Django Signals

# It's like trigger in database. It will run only when Data is Added in CustomUser model

@receiver(post_save, sender=CustomUser)
# Now Creating a Function which will automatically insert data in HOD, Staff or Student
def create_user_profile(sender, instance, created, **kwargs):
    # if Created is true (Means Data Inserted)
    if created:
        # Check the user_type and insert the data in respective tables
        if instance.user_type == 1:
            AdminHOD.objects.create(admin=instance)
        if instance.user_type == 2:
            Staffs.objects.create(admin=instance)
       
@receiver(post_save, sender=CustomUser)
def save_user_profile(sender, instance, **kwargs):
    if instance.user_type == 1:
        instance.adminhod.save()
    if instance.user_type == 2:
        instance.staffs.save()
 
    


