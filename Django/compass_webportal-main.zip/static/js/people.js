console.log("aamir");
console.log("ali");