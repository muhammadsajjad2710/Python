
from django.urls import path
from . import views
from .import HodViews



urlpatterns = [
    path('', views.loginPage, name="login"),
    # path('accounts/', include('django.contrib.auth.urls')),
    path('doLogin/', views.doLogin, name="doLogin"),
    path('get_user_details/', views.get_user_details, name="get_user_details"),
    path('logout_user/', views.logout_user, name="logout_user"),
  
    path('admin_home/', HodViews.admin_home, name="admin_home"),
    path('get_performer_data/', HodViews.get_performer_data, name="get_performer_data"),
    path('activity_details/', HodViews.activity_details, name="activity_details"),
    path('performer_details/', HodViews.performer_details, name="performer_details"),
    path('contract_details_template/', HodViews.contract_details_template, name="contract_details_template"),
    path('add_contract/', HodViews.add_contract, name="add_contract"),
    path('add_contract_save/', HodViews.add_contract_save, name='add_contract_save'),
    path('edit_contract/<int:contract_id>/', HodViews.edit_contract, name='edit_contract'), 
    path('delete_contract/<int:contract_id>/', HodViews.delete_contract, name='delete_contract'),
    

    path('check_email_exist/', HodViews.check_email_exist, name="check_email_exist"),
    path('check_username_exist/', HodViews.check_username_exist, name="check_username_exist"),
   
    path('admin_profile/', HodViews.admin_profile, name="admin_profile"),
    path('admin_profile_update/', HodViews.admin_profile_update, name="admin_profile_update"),
    


    path('dashboard/', HodViews.dashboard, name='dashboard'),
    path('complet_dashboard/', HodViews.complet_dashboard, name='complet_dashboard'),
    
]

