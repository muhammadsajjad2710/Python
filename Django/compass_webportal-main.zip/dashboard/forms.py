from django import forms 
from django.forms import Form



class DateInput(forms.DateInput):
    input_type = "date"

