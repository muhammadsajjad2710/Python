from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, AdminHOD, Contract, Performer, DataReport
# Register your models here.
class UserModel(UserAdmin):
    pass


admin.site.register(CustomUser, UserModel)

admin.site.register(AdminHOD)

@admin.register(Contract)
class ContractAdmin(admin.ModelAdmin):
    list_display = ['id', 'Contract_ID', 'Commissioner', 'ContractType', 'Start_Date', 'End_Date', 'Status']
    search_fields = ['Commissioner', 'Provider']

@admin.register(Performer)
class PerformerAdmin(admin.ModelAdmin):
    list_display = ['id', 'Performer_ID', 'Surname', 'Forename', 'GDC_Number']
    search_fields = ['Performer_ID', 'Surname', 'Forename', 'GDC_Number']



@admin.register(DataReport)
class DataReportAdmin(admin.ModelAdmin):
    list_display = ['id', 'CRN_IN', 'ContractID', 'PerformerID', 'Errors', 'PatientSurname', 'PatientForename', 'DateOfBirth', 'TreatmentStartDate', 'TreatmentEndDate', 'PatientCharge', 'Period', 'Units', 'ContraPeriod_Units_PCharge', 'NHSNumber', 'ProcessingDate', 'Status', 'FormType', 'CreatedAmendedDeletedby', 'CreationAmendDeletionDate']
    search_fields = ['CRN_IN', 'ContractID', 'PerformerID', 'Errors', 'PatientSurname', 'PatientForename', 'NHSNumber', 'Status', 'FormType']
