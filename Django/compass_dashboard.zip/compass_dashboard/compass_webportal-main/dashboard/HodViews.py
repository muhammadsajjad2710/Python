from django.shortcuts import render, redirect
from django.http import HttpResponse,  JsonResponse
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from .models import DataReport, ContractedUDAsDetails
from django.db.models import Sum
import json
from dashboard.models import CustomUser,  Contract, Performer
import pyodbc
from datetime import datetime
from django.db.models import Q
from django.views.decorators.http import require_POST
from django.shortcuts import get_object_or_404
from datetime import  timedelta
from django.utils import timezone

def admin_home(request):
    all_contracts_count = Contract.objects.all().count()
    all_performers_count = Performer.objects.all().count()
    all_actvity_count = DataReport.objects.all().count()
    all_failed_count = DataReport.objects.filter(Q(Status='Deleted') | Q(Status='Failed Validation')).count()

    context={
        "all_contracts_count": all_contracts_count,
        "all_performers_count": all_performers_count,
        "all_actvity_count": all_actvity_count,
        "all_failed_count": all_failed_count,
    }
    return render(request, "hod_template/home_content.html", context)




@require_POST
def get_performer_data(request):
    performer_id = request.POST.get('performer_id')
    data_reports = DataReport.objects.filter(PerformerID=performer_id)[:10]
    serialized_data = [
        {
            'id': data_report.id,
            'CRN_IN': data_report.CRN_IN,
            'ContractID': data_report.ContractID,
            'PerformerID': data_report.PerformerID,
            'Errors': data_report.Errors,
            'PatientSurname': data_report.PatientSurname,
            'PatientForename': data_report.PatientForename,
            'DateOfBirth': data_report.DateOfBirth,
            'TreatmentStartDate': data_report.TreatmentStartDate,
            'TreatmentEndDate': data_report.TreatmentEndDate,
            'PatientCharge': data_report.PatientCharge,
            'Period': data_report.Period,
            'Units': data_report.Units,
            'ContraPeriod_Units_PCharge': data_report.ContraPeriod_Units_PCharge,
            'NHSNumber': data_report.NHSNumber,
            'ProcessingDate': data_report.ProcessingDate,
            'Status': data_report.Status,
            'FormType': data_report.FormType,
            'CreatedAmendedDeletedby': data_report.CreatedAmendedDeletedby,
            'CreationAmendDeletionDate': data_report.CreationAmendDeletionDate,
        }
        for data_report in data_reports
    ]

    return JsonResponse({'data_reports': serialized_data})



#migratedata()
def activity_details(request):
    #migratedata()
    all_performers = Performer.objects.all()
    start_date = request.POST.get('start_date', '')
    end_date = request.POST.get('end_date', '')
    contract_id = request.POST.get('contract_id', '')

    if request.method == 'POST':
        # Process the POST request data if needed
        start_date_str = start_date
        end_date_str = end_date

        if start_date_str and end_date_str:
            try:
                # Convert string inputs to datetime objects
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
                end_date = datetime.strptime(end_date_str, '%Y-%m-%d')

                # Filter data using the date range and Contract ID
                data_reports = DataReport.objects.filter(
                    ProcessingDate__range=[start_date, end_date],
                    ContractID=contract_id
                )[:10]
            except ValueError:
                # Handle invalid date format
                data_reports = None
        else:
            # If no date range provided, handle as needed
            data_reports = None  # For example, you might set data_reports to some default value or display an error message
    else:
        # If it's not a POST request, fetch the top 10 rows
        data_reports = DataReport.objects.all()[:10]

    context = {
        "all_performers" : all_performers,
        "data_reports": data_reports,
        "start_date": start_date,
        "end_date": end_date,
        "contract_id": contract_id,
    }
    return render(request, "hod_template/activity_details_template.html", context)


def performer_details(request):
    Performers = Performer.objects.all()
    context = {
        "performers": Performers
    }
    return render(request, "hod_template/performer_details_template.html", context)

def contract_details_template(request):
    contracts = Contract.objects.all()
    context = {"contracts": contracts}
    return render(request, "hod_template/contract_details_template.html", context)

def add_contract(request):
    return render(request, "hod_template/add_contract.html")

def add_contract_save(request):
    if request.method == 'POST':
        contract_data = request.POST
        try:
            Contract.objects.create(
                Contract_ID=contract_data['Contract_ID'],
                Contract_UDAs=contract_data['Contract_UDAs'],
                Commissioner=contract_data['Commissioner'],
                ContractType=contract_data['ContractType'],
                Start_Date=contract_data['Start_Date'],
                End_Date=contract_data['End_Date'],
                Status=contract_data['Status']
            )
            messages.success(request, "Contract Added Successfully!")
            return redirect('contract_details_template')

        except Exception as e:
            messages.error(request, f"Failed to Add Contract: {str(e)}")
    return render(request, "hod_template/add_contract.html")

def edit_contract(request, contract_id):
    contract = get_object_or_404(Contract, id=contract_id)
    if request.method == "POST":
        contract_data = request.POST
        try:
            contract.Contract_ID = contract_data['Contract_ID']
            contract.Contract_UDAs = contract_data['Contract_UDAs']
            contract.Commissioner = contract_data['Commissioner']
            contract.ContractType = contract_data['ContractType']
            contract.Start_Date = contract_data['Start_Date']
            contract.End_Date = contract_data['End_Date']
            contract.Status = contract_data['Status']
            contract.save()
            messages.success(request, "Contract details updated successfully!")
            # Redirect to the appropriate URL or view name
            return redirect('contract_details_template')
        except Exception as e:
            messages.error(request, f"Failed to update contract details: {str(e)}")
    return render(request, "hod_template/edit_contract_details.html", {'contract': contract})


def delete_contract(request, contract_id):
    if request.method == "POST" or request.method == "GET":
        contract = get_object_or_404(Contract, id=contract_id)
        contract.delete()
        messages.success(request, "Contract deleted successfully!")
    return redirect('contract_details_template')  # Redirect to contract details page



@csrf_exempt
def check_email_exist(request):
    email = request.POST.get("email")
    user_obj = CustomUser.objects.filter(email=email).exists()
    if user_obj:
        return HttpResponse(True)
    else:
        return HttpResponse(False)


@csrf_exempt
def check_username_exist(request):
    username = request.POST.get("username")
    user_obj = CustomUser.objects.filter(username=username).exists()
    if user_obj:
        return HttpResponse(True)
    else:
        return HttpResponse(False)




def admin_profile(request):
    user = CustomUser.objects.get(id=request.user.id)

    context={
        "user": user
    }
    return render(request, 'hod_template/admin_profile.html', context)


def admin_profile_update(request):
    if request.method != "POST":
        messages.error(request, "Invalid Method!")
        return redirect('admin_profile')
    else:
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        password = request.POST.get('password')

        try:
            customuser = CustomUser.objects.get(id=request.user.id)
            customuser.first_name = first_name
            customuser.last_name = last_name
            if password != None and password != "":
                customuser.set_password(password)
            customuser.save()
            messages.success(request, "Profile Updated Successfully")
            return redirect('admin_profile')
        except:
            messages.error(request, "Failed to Update Profile")
            return redirect('admin_profile')
    






# SQL Server connection details with Windows authentication
server_name = 'IMRANKHAN\\SQLEXPRESS'  # Note the double backslash
database_name = 'postgres'

# Establish a connection to the SQL Server database with integrated security
conn_str = f'DRIVER={{SQL Server}};SERVER={server_name};DATABASE={database_name};Trusted_Connection=yes;'




def migratedata():
    # Connect to SQL Server
    sql_server_connection = pyodbc.connect(conn_str)
    sql_server_cursor = sql_server_connection.cursor()
    # Fetch data from data_report table
    sql_server_cursor.execute('SELECT * FROM data_report')
    data_report_rows = sql_server_cursor.fetchall()

    # Insert data into DataReport model
    for row in data_report_rows:
        print(row)
        data_report_instance = DataReport(
        CRN_IN=str(row[0]),  # Update with the actual index of CRN_IN column
        ContractID=str(row[1]),  # Update with the actual index of ContractID column
        PerformerID=str(row[2]),  # Update with the actual index of PerformerID column
        Errors=str(row[3]),  # Update with the actual index of Errors column
        PatientSurname=str(row[4]),  # Update with the actual index of PatientSurname column
        PatientForename=str(row[5]),  # Update with the actual index of PatientForename column
        DateOfBirth=datetime.strptime(row[6], '%d/%m/%Y') if row[6] and row[6] != 'nan' else None,
        TreatmentStartDate=datetime.strptime(row[7], '%d/%m/%Y') if row[7] and row[7] != 'nan' else None,
        TreatmentEndDate=datetime.strptime(row[8], '%d/%m/%Y') if row[8] and row[8] != 'nan' else None,
        PatientCharge=str(row[9]),  # Update with the actual index of PatientCharge column
        Period=str(row[10]),  # Update with the actual index of Period column
        Units=str(row[11]),  # Update with the actual index of Units column
        ContraPeriod_Units_PCharge=str(row[12]),  # Update with the actual index
        NHSNumber=str(row[13]),  # Update with the actual index of NHSNumber column
        ProcessingDate=datetime.strptime(row[14], '%d/%m/%Y') if row[14] and row[14] != 'nan' else None,
        Status=str(row[15]),  # Update with the actual index of Status column
        FormType=str(row[16]),  # Update with the actual index of FormType column
        CreatedAmendedDeletedby=str(row[17]),
        CreationAmendDeletionDate=datetime.strptime(row[18], '%d/%m/%Y %H:%M:%S') if row[18] and row[18] != 'nan' else None,
    )
        data_report_instance.save()

    sql_server_cursor.execute('SELECT * FROM Performers')
    performers_rows = sql_server_cursor.fetchall()

            # Insert data into Performer model
    for row in performers_rows:
        performer_instance = Performer(
                    Performer_ID=row[0],  # Update with the actual index of Performer_ID column
                    Surname=row[1],  # Update with the actual index of Surname column
                    Forename=row[2],  # Update with the actual index of Forename column
                    GDC_Number=row[3],  # Update with the actual index of GDC_Number column
                )
        performer_instance.save()
      
            # Fetch data from contract_id table
    sql_server_cursor.execute('SELECT * FROM contract_id')
    contract_rows = sql_server_cursor.fetchall()

            # Insert data into Contract model
    for row in contract_rows:
        print(row)
        contract_instance = Contract(
                    Contract_ID=row[0],  # Update with the actual index of Contract_ID column
                    Commissioner=row[1],  # Update with the actual index of Commissioner column
                    ContractType=row[2],  # Update with the actual index of Provider column
                    Start_Date=row[3],  # Update with the actual index of Provider_Type column
                    End_Date=row[4],  # Update with the actual index of Start_Date column
                    Status=row[5],  # Update with the actual index of End_Date column
                )
        contract_instance.save()
    # Close connections
    sql_server_cursor.close()
    sql_server_connection.close()
    



def dashboard(request):
    today = timezone.now()
    start_date = today - timedelta(days=14)
    end_date = today + timedelta(days=6)

    labels = [(start_date + timedelta(days=i)).strftime('%d/%m/%Y') for i in range(21)]
    contract_ids = DataReport.objects.values_list('ContractID', flat=True).distinct()

    contracted_udas_details = ContractedUDAsDetails.objects.all()

    contract_data = {
        detail.contract_id: {
            'contracted_udas': int(detail.contracted_udas),
            'carry_over_udas': int(detail.carry_over_udas),
            'target_udas': int(detail.contracted_udas) + int(detail.carry_over_udas),
        }
        for detail in contracted_udas_details
    }

    total_days = 365
    off_days = 38
    remaining_days = total_days - off_days
    workdays_per_week = 4
    available_workdays = remaining_days // 7 * workdays_per_week

    def get_units_for_contract(contract_id):
        validated_data = DataReport.objects.filter(
            Status='Validated',
            ProcessingDate__range=[start_date, today],
            ContractID=contract_id
        ).values_list('ProcessingDate', 'Units')

        units_dict = {timezone.localtime(date).date(): float(units) for date, units in validated_data}

        units_data_list = []
        for i in range(21):
            current_date = start_date + timedelta(days=i)
            if current_date <= today:
                units_data_list.append(units_dict.get(current_date.date(), 0))
            else:
                units_data_list.append(uda_target_per_working_day * 0.99)

        return units_data_list

    if request.method == 'POST' and request.headers.get('x-requested-with') == 'XMLHttpRequest':
        data = json.loads(request.body)
        contract_id = data.get('contract_id')

        # Fetch relevant PerformerIDs for the selected ContractID
        performer_ids = DataReport.objects.filter(ContractID=contract_id).values_list('PerformerID', flat=True).distinct()

        contract_info = contract_data.get(contract_id, {})

        total_udas = float(contract_info.get('target_udas', 0))
        uda_target_per_working_day = total_udas / available_workdays

        target_data = []
        for i in range(21):
            current_date = start_date + timedelta(days=i)
            if current_date.weekday() < workdays_per_week:
                target_data.append(uda_target_per_working_day)
            else:
                target_data.append(0)

        units_data = get_units_for_contract(contract_id)

        today_offset = (today - start_date).days
        tomorrow_offset = today_offset + 1

        if tomorrow_offset < len(target_data):
            tomorrow_target = round(target_data[tomorrow_offset])
        else:
            tomorrow_target = None

        return JsonResponse({
            'target_data': target_data,
            'units_data': units_data,
            'today_target': round(target_data[today_offset]),
            'tomorrow_target': tomorrow_target,
            'performer_ids': list(performer_ids),  # Return relevant performer IDs
        })

    else:
        contract_info = contract_data.get(contract_ids[0], {}) if contract_ids else {}

        total_udas = float(contract_info.get('target_udas', 0))
        uda_target_per_working_day = total_udas / available_workdays

        target_data = []
        for i in range(21):
            current_date = start_date + timedelta(days=i)
            if current_date.weekday() < workdays_per_week:
                target_data.append(uda_target_per_working_day)
            else:
                target_data.append(0)

        units_data = get_units_for_contract(contract_ids[0])

        today_index = (today - start_date).days
        tomorrow_index = today_index + 1

        if tomorrow_index < len(target_data):
            tomorrow_target = round(target_data[tomorrow_index])
        else:
            tomorrow_target = None

        # Fetch Performer IDs for the first contract ID to display initially
        initial_performer_ids = DataReport.objects.filter(ContractID=contract_ids[0]).values_list('PerformerID', flat=True).distinct()

        context = {
            'labels': labels,
            'target_data': target_data,
            'units_data': units_data,
            'today_index': today_index,
            'today_label': today.strftime('%d/%m/%Y'),
            'contract_ids': contract_ids,
            'performer_ids': initial_performer_ids,  # Performer IDs for the first contract
            'today_target': round(target_data[today_index]),
            'tomorrow_target': tomorrow_target,
        }

    return render(request, 'hod_template/dashboard.html', context)



def units_sum(contract_id):
    # Define the date range
    start_date = timezone.make_aware(datetime(2024, 4, 1))  # Ensure timezone awareness
    today = timezone.now()  # Get current time with timezone awareness

    # Sum the units within the date range and with Status 'Validated'
    total_units = DataReport.objects.filter(
        ContractID=contract_id,
        Status='Validated',
        ProcessingDate__range=[start_date, today]  # Only sum till today's date
    ).aggregate(total_units=Sum('Units'))['total_units'] or 0

    print(f"Contract ID: {contract_id}")
    print(f"Sum of units till today's date: {total_units}")

    return total_units  # Return total units from start_date to today's date


def complet_dashboard(request):
    today = timezone.now()  # Get current time with timezone awareness
    start_date = timezone.make_aware(datetime(2024, 4, 1))  # Ensure timezone awareness
    end_date = timezone.make_aware(datetime(2025, 3, 31))  # Timezone-aware

    # Generate date labels for the entire year
    labels = [(start_date + timedelta(days=i)).strftime('%d/%m/%Y') for i in range((end_date - start_date).days + 1)]
    
    # Fetch distinct contract IDs from DataReport
    contract_ids = DataReport.objects.values_list('ContractID', flat=True).distinct()

    # Calculate total working days and available workdays
    total_days = 365
    off_days = 38
    remaining_days = total_days - off_days
    workdays_per_week = 4  # Monday to Thursday are working days
    available_workdays = remaining_days // 7 * workdays_per_week

    # Fetch contracted UDA details from ContractedUDAsDetails table
    contracted_udas_details = ContractedUDAsDetails.objects.all()

    # Prepare contract data dictionary
    contract_data = {
        detail.contract_id: {
            'contracted_udas': int(detail.contracted_udas),
            'carry_over_udas': int(detail.carry_over_udas),
            'target_udas': int(detail.contracted_udas) + int(detail.carry_over_udas),
        }
        for detail in contracted_udas_details
    }

    if request.method == 'POST' and request.headers.get('x-requested-with') == 'XMLHttpRequest':
        data = json.loads(request.body)
        contract_id = data.get('contract_id')

        if contract_id:
            # Fetch relevant PerformerIDs for the selected ContractID
            performer_ids = DataReport.objects.filter(ContractID=contract_id).values_list('PerformerID', flat=True).distinct()

            # Fetch contract details from the prepared dictionary
            contract_info = contract_data.get(contract_id, {})

            # Calculate UDA target per working day
            total_udas = float(contract_info.get('target_udas', 0))
            uda_target_per_working_day = total_udas / available_workdays if available_workdays > 0 else 0

            # Create a cumulative UDA target curve for the entire year
            cumulative_udas = 0
            data_uda_target_curve = []

            current_date = start_date
            while current_date <= end_date:
                day_of_week = current_date.weekday()  # 0 = Monday, 6 = Sunday
                if day_of_week < 4:  # Monday to Thursday are working days
                    cumulative_udas += uda_target_per_working_day

                # Append UDA target curve
                data_uda_target_curve.append(round(cumulative_udas, 2))

                labels.append(current_date.strftime("%d-%m-%Y"))
                current_date += timedelta(days=1)

            # Fetch total_units using the people_table function
            total_units = units_sum(contract_id)

            # Create a cumulative units curve (up to today)
            data_units_till_today = []
            cumulative_units = 0
            current_date = start_date
            while current_date <= end_date:
                if current_date <= today:
                    # Use the cumulative total_units up to today
                    cumulative_units = total_units
                else:
                    # After today's date, use 99% of the target UDA curve
                    cumulative_units = cumulative_udas * 0.99

                data_units_till_today.append(round(cumulative_units, 2))
                current_date += timedelta(days=1)

            # Return JSON response for AJAX
            return JsonResponse({
                'target_data': data_uda_target_curve,
                'units_till_today': data_units_till_today,
                'labels': labels,
                'today_target': uda_target_per_working_day,
                'performer_ids': list(performer_ids),  # Return relevant performer IDs
            })

    else:
        today_index = (today - start_date).days

        context = {
            'labels': labels,
            'contract_ids': contract_ids,  # Contract IDs from DataReport
            'performer_ids': [],  # Initially no performer IDs
            'today_index': today_index,
            'today_label': today.strftime('%d/%m/%Y'),
        }

    return render(request, 'hod_template/complete_dashboard.html', context)





