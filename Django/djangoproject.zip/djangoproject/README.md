# Django Blog Project

A modern, responsive blog application built with Django and Bootstrap.

## Features

- **User Authentication**: Login/logout functionality with Django's built-in admin
- **Blog Posts**: Create, read, update, and delete blog posts
- **Responsive Design**: Modern UI with Bootstrap 5 and Font Awesome icons
- **Admin Interface**: Full admin panel for managing posts and users
- **Author Management**: Posts are associated with specific authors

## Project Structure

```
djangoproject/
├── blog/                    # Blog application
│   ├── templates/blog/      # HTML templates
│   ├── models.py           # Database models
│   ├── views.py            # View functions
│   ├── forms.py            # Form classes
│   ├── urls.py             # URL patterns
│   └── admin.py            # Admin configuration
├── blog_project/           # Main project settings
├── manage.py              # Django management script
├── requirements.txt       # Python dependencies
└── README.md             # This file
```

## Installation

1. **Clone or download the project**

2. **Create a virtual environment** (recommended):
   ```bash
   python -m venv venv
   ```

3. **Activate the virtual environment**:
   - Windows: `venv\Scripts\activate`
   - macOS/Linux: `source venv/bin/activate`

4. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

5. **Run database migrations**:
   ```bash
   python manage.py migrate
   ```

6. **Create a superuser** (optional):
   ```bash
   python manage.py createsuperuser
   ```

## Running the Application

1. **Start the development server**:
   ```bash
   python manage.py runserver
   ```

2. **Open your browser** and navigate to:
   - Main blog: http://127.0.0.1:8000/
   - Admin panel: http://127.0.0.1:8000/admin/

## Default Admin Credentials

- **Username**: admin
- **Password**: admin123

## Usage

### For Visitors
- Browse blog posts on the homepage
- Click "Read More" to view full posts
- View post details including author and publication date

### For Authors (Logged-in Users)
- Create new blog posts
- Edit your own posts
- Access the admin panel for advanced management

### For Administrators
- Manage all posts and users through the admin interface
- Create, edit, and delete any post
- Manage user accounts and permissions

## Features in Detail

### Blog Posts
- **Title**: Post title (required)
- **Content**: Full post content with rich text support
- **Author**: Automatically assigned to the logged-in user
- **Timestamps**: Creation and publication dates
- **Status**: Published posts appear on the homepage

### User Interface
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Modern Styling**: Clean, professional appearance with Bootstrap
- **Icons**: Font Awesome icons for better visual appeal
- **Navigation**: Easy navigation between pages

### Security
- **CSRF Protection**: Built-in Django CSRF protection
- **User Authentication**: Login required for creating/editing posts
- **Author Permissions**: Users can only edit their own posts

## Customization

### Adding New Features
1. Create new models in `blog/models.py`
2. Add views in `blog/views.py`
3. Create templates in `blog/templates/blog/`
4. Update URLs in `blog/urls.py`

### Styling
- Modify `blog/templates/blog/base.html` for global styling
- Add custom CSS in template files
- Update Bootstrap classes for different layouts

## Deployment

For production deployment:

1. **Set DEBUG = False** in `blog_project/settings.py`
2. **Configure a production database** (PostgreSQL recommended)
3. **Set up static file serving**
4. **Use a production WSGI server** (Gunicorn, uWSGI)
5. **Configure your web server** (Nginx, Apache)

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source and available under the MIT License.

## Support

For questions or issues, please create an issue in the project repository.
