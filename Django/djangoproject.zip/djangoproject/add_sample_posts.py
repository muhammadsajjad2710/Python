#!/usr/bin/env python
import os
import sys
import django
from django.utils import timezone

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'blog_project.settings')
django.setup()

from blog.models import Post
from django.contrib.auth.models import User

def create_sample_posts():
    # Get or create a user for the posts
    user, created = User.objects.get_or_create(
        username='admin',
        defaults={
            'email': 'admin@example.com',
            'first_name': 'Admin',
            'last_name': 'User'
        }
    )
    
    if created:
        user.set_password('admin123')
        user.save()
        print(f"Created user: {user.username}")
    else:
        print(f"Using existing user: {user.username}")
    
    # Sample blog posts data
    sample_posts = [
        {
            'title': 'Getting Started with Django: A Beginner\'s Guide',
            'text': '''Django is a high-level Python web framework that encourages rapid development and clean, pragmatic design. Built by experienced developers, it takes care of much of the hassle of web development, so you can focus on writing your app without needing to reinvent the wheel.

## Why Choose Django?

Django follows the "batteries-included" philosophy and provides almost everything developers might want to do out of the box. Because everything you need is part of the one "product", it all works seamlessly together, follows consistent design principles, and has extensive and up-to-date documentation.

### Key Features:
- **Object-Relational Mapping (ORM)**: Django's ORM provides a high-level abstraction over your database, allowing you to work with Python objects instead of writing raw SQL.
- **Admin Interface**: Django automatically generates an admin interface for your models, making it easy to manage your data.
- **Security**: Django includes built-in protection against common security vulnerabilities like SQL injection, cross-site scripting, and CSRF attacks.
- **Scalability**: Django is designed to handle high-traffic websites and can scale to meet the demands of large applications.

## Getting Started

To start a new Django project, you'll need to:

1. Install Django: `pip install django`
2. Create a project: `django-admin startproject myproject`
3. Run migrations: `python manage.py migrate`
4. Start the server: `python manage.py runserver`

Django's documentation is excellent and provides comprehensive guides for both beginners and advanced users. Whether you're building a simple blog or a complex web application, Django provides the tools you need to succeed.

The framework's emphasis on rapid development, clean design, and practical solutions makes it an excellent choice for developers of all skill levels.'''
        },
        {
            'title': 'The Future of Web Development: Trends to Watch in 2024',
            'text': '''As we move through 2024, the web development landscape continues to evolve at a rapid pace. New technologies, frameworks, and methodologies are reshaping how we build and deploy web applications. Let's explore some of the most significant trends that are defining the future of web development.

## 1. AI-Powered Development Tools

Artificial Intelligence is revolutionizing how developers write code. From intelligent code completion to automated testing and debugging, AI tools are becoming indispensable in modern development workflows.

### Key Developments:
- **GitHub Copilot and Similar Tools**: AI-powered code completion that understands context and suggests relevant code snippets
- **Automated Testing**: AI can generate test cases and identify potential bugs before they reach production
- **Code Review Automation**: AI tools can review code for best practices, security vulnerabilities, and performance issues

## 2. WebAssembly (WASM) Adoption

WebAssembly is enabling high-performance applications to run in the browser at near-native speeds. This technology is opening up new possibilities for web applications that were previously only possible with desktop software.

### Use Cases:
- **Gaming**: Complex 3D games running directly in the browser
- **Video Editing**: Professional-grade video editing tools accessible through web browsers
- **Scientific Computing**: Running computationally intensive algorithms in the browser

## 3. Progressive Web Apps (PWAs)

PWAs continue to gain traction as they bridge the gap between web and native applications. They offer the best of both worlds: the reach of the web and the performance of native apps.

### Benefits:
- **Offline Functionality**: PWAs can work without an internet connection
- **App-like Experience**: They provide native app-like interactions and performance
- **Easy Distribution**: No app store approval process required

## 4. Micro-Frontends Architecture

This architectural pattern allows teams to work independently on different parts of a web application, leading to faster development cycles and better maintainability.

### Advantages:
- **Team Autonomy**: Different teams can work on different parts of the application
- **Technology Diversity**: Different parts can use different frameworks or technologies
- **Independent Deployment**: Teams can deploy their changes without affecting others

## 5. Serverless Computing

Serverless architecture is becoming increasingly popular for web applications, offering automatic scaling and reduced operational overhead.

### Benefits:
- **Cost Efficiency**: Pay only for actual usage
- **Automatic Scaling**: Infrastructure scales automatically with demand
- **Reduced Maintenance**: No server management required

## Looking Ahead

The future of web development is exciting and full of possibilities. As these trends continue to mature, we can expect to see even more innovative applications and development practices emerge. The key for developers is to stay adaptable and continuously learn new technologies while maintaining a solid foundation in core web development principles.

Whether you're a seasoned developer or just starting your journey, these trends offer opportunities to build more powerful, efficient, and user-friendly web applications than ever before.'''
        },
        {
            'title': 'Mastering CSS Grid: A Complete Guide to Modern Layouts',
            'text': '''CSS Grid has revolutionized how we create layouts on the web. It's a powerful two-dimensional layout system that gives developers unprecedented control over how elements are positioned and sized. Let's dive deep into CSS Grid and explore how to master this essential technology.

## Understanding CSS Grid Fundamentals

CSS Grid is a layout system designed for the two-dimensional layout of items on a webpage or application. It lets you lay out items in rows and columns, and has many features that make building complex layouts straightforward.

### Basic Concepts:
- **Grid Container**: The element on which `display: grid` is applied
- **Grid Item**: The direct children of the grid container
- **Grid Line**: The dividing lines that make up the structure of the grid
- **Grid Track**: The space between two adjacent grid lines
- **Grid Cell**: The space between four grid lines
- **Grid Area**: The total space surrounded by four grid lines

## Creating Your First Grid

```css
.container {
  display: grid;
  grid-template-columns: 200px 200px 200px;
  grid-template-rows: 100px 100px;
  gap: 20px;
}
```

This simple example creates a 3x2 grid with 200px wide columns and 100px tall rows, with 20px gaps between items.

## Advanced Grid Techniques

### 1. Fractional Units (fr)
The `fr` unit represents a fraction of the available space in the grid container.

```css
.container {
  display: grid;
  grid-template-columns: 1fr 2fr 1fr;
}
```

This creates three columns where the middle column takes twice the space of the side columns.

### 2. Grid Areas
Grid areas allow you to name sections of your grid and place items by referencing those names.

```css
.container {
  display: grid;
  grid-template-areas: 
    "header header header"
    "sidebar content content"
    "footer footer footer";
}

.header { grid-area: header; }
.sidebar { grid-area: sidebar; }
.content { grid-area: content; }
.footer { grid-area: footer; }
```

### 3. Responsive Grids
CSS Grid makes it easy to create responsive layouts that adapt to different screen sizes.

```css
.container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
}
```

This creates a responsive grid where columns automatically adjust based on available space.

## Real-World Applications

### 1. Card Layouts
CSS Grid is perfect for creating card-based layouts that automatically adjust to content and screen size.

### 2. Dashboard Layouts
Complex dashboard interfaces benefit greatly from Grid's ability to create precise, flexible layouts.

### 3. Photo Galleries
Grid's ability to handle different-sized items makes it ideal for creating dynamic photo galleries.

## Best Practices

1. **Start Simple**: Begin with basic grid layouts and gradually add complexity
2. **Use Named Lines**: Give your grid lines meaningful names for better maintainability
3. **Embrace the Gap Property**: Use `gap` instead of margins for spacing between grid items
4. **Plan Your Layout**: Sketch out your grid structure before coding
5. **Test Responsiveness**: Always test your grids on different screen sizes

## Browser Support

CSS Grid is now supported in all modern browsers, making it safe to use in production. For older browsers, consider providing fallback layouts using Flexbox or traditional positioning.

## Conclusion

CSS Grid is a game-changer for web layout. Its powerful features and intuitive syntax make it the go-to choice for creating complex, responsive layouts. By mastering CSS Grid, you'll be able to create layouts that were previously impossible or extremely difficult to achieve.

The key to mastering CSS Grid is practice. Start with simple layouts and gradually work your way up to more complex designs. With time and experience, you'll find that CSS Grid becomes an essential tool in your web development toolkit.'''
        },
        {
            'title': 'JavaScript ES6+ Features Every Developer Should Know',
            'text': '''JavaScript has evolved significantly since the introduction of ES6 (ECMAScript 2015). Modern JavaScript includes powerful features that make code more readable, maintainable, and efficient. Let's explore the most important ES6+ features that every developer should master.

## 1. Arrow Functions

Arrow functions provide a more concise syntax for writing function expressions and have some important differences from traditional functions.

```javascript
// Traditional function
function add(a, b) {
  return a + b;
}

// Arrow function
const add = (a, b) => a + b;

// With multiple parameters
const multiply = (a, b, c) => {
  const result = a * b * c;
  return result;
};
```

### Key Benefits:
- **Shorter syntax** for simple functions
- **Lexical `this` binding** (no need for `.bind()` or `that = this`)
- **Implicit return** for single expressions

## 2. Destructuring Assignment

Destructuring allows you to extract values from objects and arrays into distinct variables.

```javascript
// Object destructuring
const person = { name: 'John', age: 30, city: 'New York' };
const { name, age, city } = person;

// Array destructuring
const colors = ['red', 'green', 'blue'];
const [first, second, third] = colors;

// Nested destructuring
const user = {
  id: 1,
  profile: {
    name: 'Jane',
    email: 'jane@example.com'
  }
};
const { profile: { name, email } } = user;
```

## 3. Template Literals

Template literals provide an elegant way to work with strings and embed expressions.

```javascript
const name = 'World';
const greeting = `Hello, ${name}!`;

// Multi-line strings
const message = `
  This is a multi-line
  string that preserves
  formatting and indentation.
`;

// Expression interpolation
const price = 19.99;
const quantity = 3;
const total = `Total: $${(price * quantity).toFixed(2)}`;
```

## 4. Spread and Rest Operators

The spread operator (`...`) allows you to expand elements, while the rest operator collects multiple elements into an array.

```javascript
// Spread operator
const numbers = [1, 2, 3];
const moreNumbers = [...numbers, 4, 5, 6];

// Object spreading
const defaults = { theme: 'dark', language: 'en' };
const userSettings = { ...defaults, theme: 'light' };

// Rest operator
const sum = (...args) => args.reduce((total, num) => total + num, 0);
```

## 5. Classes

ES6 introduced a more familiar class syntax for creating objects and implementing inheritance.

```javascript
class Animal {
  constructor(name) {
    this.name = name;
  }
  
  speak() {
    return `${this.name} makes a sound.`;
  }
}

class Dog extends Animal {
  speak() {
    return `${this.name} barks.`;
  }
}

const dog = new Dog('Rex');
console.log(dog.speak()); // "Rex barks."
```

## 6. Modules

ES6 modules provide a standardized way to organize and share code between files.

```javascript
// math.js
export const add = (a, b) => a + b;
export const subtract = (a, b) => a - b;
export default class Calculator {
  // ...
}

// main.js
import Calculator, { add, subtract } from './math.js';
```

## 7. Promises and Async/Await

Modern JavaScript provides powerful tools for handling asynchronous operations.

```javascript
// Promises
const fetchData = () => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve('Data fetched successfully!');
    }, 1000);
  });
};

// Async/Await
const getData = async () => {
  try {
    const result = await fetchData();
    console.log(result);
  } catch (error) {
    console.error('Error:', error);
  }
};
```

## 8. Optional Chaining and Nullish Coalescing

These features help handle null and undefined values more gracefully.

```javascript
// Optional chaining
const user = {
  profile: {
    address: {
      street: '123 Main St'
    }
  }
};

const street = user?.profile?.address?.street; // Safe access

// Nullish coalescing
const name = user?.name ?? 'Anonymous'; // Only falls back if null/undefined
```

## 9. Map and Set

ES6 introduced new collection types that provide better alternatives to objects and arrays in certain scenarios.

```javascript
// Map
const userMap = new Map();
userMap.set('id', 1);
userMap.set('name', 'John');

// Set
const uniqueNumbers = new Set([1, 2, 2, 3, 3, 4]);
console.log([...uniqueNumbers]); // [1, 2, 3, 4]
```

## Best Practices

1. **Use const by default**: Only use `let` when you need to reassign variables
2. **Prefer arrow functions** for callbacks and simple functions
3. **Use destructuring** to make code more readable
4. **Embrace async/await** for asynchronous operations
5. **Use template literals** for string interpolation
6. **Leverage the spread operator** for immutable operations

## Conclusion

These ES6+ features have transformed JavaScript into a more powerful and expressive language. By mastering these features, you'll write cleaner, more maintainable code and be better equipped to work with modern JavaScript frameworks and libraries.

The key is to practice these features in real projects and gradually incorporate them into your coding style. With time, these modern JavaScript features will become second nature and significantly improve your development experience.'''
        },
        {
            'title': 'Building RESTful APIs with Django REST Framework',
            'text': '''Django REST Framework (DRF) is a powerful and flexible toolkit for building Web APIs. It provides a comprehensive set of tools for creating RESTful APIs that are both robust and easy to maintain. Let's explore how to build professional APIs using DRF.

## What is Django REST Framework?

Django REST Framework is a third-party package that extends Django's capabilities for building APIs. It provides serializers, viewsets, and other tools that make it easy to convert Django models into RESTful APIs.

### Key Features:
- **Serializers**: Convert complex data types to and from JSON
- **ViewSets**: Combine common operations into single classes
- **Routers**: Automatically generate URL patterns for ViewSets
- **Authentication**: Built-in support for various authentication methods
- **Permissions**: Flexible permission system
- **Throttling**: Rate limiting for API endpoints

## Setting Up DRF

First, install Django REST Framework:

```bash
pip install djangorestframework
```

Add it to your `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    # ...
    'rest_framework',
]
```

## Creating Serializers

Serializers convert Django model instances to JSON and vice versa.

```python
from rest_framework import serializers
from .models import Post

class PostSerializer(serializers.ModelSerializer):
    author_name = serializers.ReadOnlyField(source='author.username')
    
    class Meta:
        model = Post
        fields = ['id', 'title', 'text', 'author_name', 'published_date']
        read_only_fields = ['published_date']
```

## Building API Views

DRF provides several ways to create API views, from simple function-based views to powerful ViewSets.

### Function-Based Views

```python
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status

@api_view(['GET', 'POST'])
def post_list(request):
    if request.method == 'GET':
        posts = Post.objects.all()
        serializer = PostSerializer(posts, many=True)
        return Response(serializer.data)
    
    elif request.method == 'POST':
        serializer = PostSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(author=request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
```

### Class-Based Views

```python
from rest_framework import generics
from rest_framework.permissions import IsAuthenticatedOrReadOnly

class PostList(generics.ListCreateAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    
    def perform_create(self, serializer):
        serializer.save(author=self.request.user)

class PostDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
```

### ViewSets

ViewSets combine common operations into single classes.

```python
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticatedOrReadOnly

class PostViewSet(viewsets.ModelViewSet):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    
    def perform_create(self, serializer):
        serializer.save(author=self.request.user)
```

## URL Configuration

DRF provides routers for automatically generating URL patterns.

```python
from rest_framework.routers import DefaultRouter
from .views import PostViewSet

router = DefaultRouter()
router.register(r'posts', PostViewSet)

urlpatterns = router.urls
```

## Authentication and Permissions

DRF provides comprehensive authentication and permission systems.

```python
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.SessionAuthentication',
        'rest_framework.authentication.TokenAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticatedOrReadOnly',
    ],
}
```

## Custom Permissions

You can create custom permissions for specific use cases.

```python
from rest_framework import permissions

class IsAuthorOrReadOnly(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        return obj.author == request.user
```

## API Documentation

DRF provides tools for generating API documentation.

```python
from drf_yasg.views import get_schema_view
from drf_yasg import openapi

schema_view = get_schema_view(
    openapi.Info(
        title="Blog API",
        default_version='v1',
        description="A simple blog API",
    ),
    public=True,
)
```

## Testing APIs

DRF includes tools for testing APIs.

```python
from rest_framework.test import APITestCase
from django.contrib.auth.models import User

class PostAPITestCase(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser',
            password='testpass123'
        )
    
    def test_create_post(self):
        self.client.force_authenticate(user=self.user)
        data = {
            'title': 'Test Post',
            'text': 'This is a test post'
        }
        response = self.client.post('/api/posts/', data)
        self.assertEqual(response.status_code, 201)
```

## Best Practices

1. **Use ViewSets** for CRUD operations on models
2. **Implement proper permissions** to secure your API
3. **Use serializers** to validate and transform data
4. **Add comprehensive tests** for your API endpoints
5. **Document your API** using tools like drf-yasg
6. **Implement pagination** for large datasets
7. **Use appropriate HTTP status codes**
8. **Add filtering and searching** capabilities

## Advanced Features

### Filtering and Searching

```python
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter

class PostViewSet(viewsets.ModelViewSet):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['author', 'published_date']
    search_fields = ['title', 'text']
    ordering_fields = ['published_date', 'title']
```

### Pagination

```python
REST_FRAMEWORK = {
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE': 10
}
```

## Conclusion

Django REST Framework provides everything you need to build professional, scalable APIs. Its comprehensive feature set, excellent documentation, and active community make it an excellent choice for API development.

By following best practices and leveraging DRF's powerful features, you can create APIs that are not only functional but also maintainable and secure. Whether you're building a simple API or a complex system, DRF provides the tools you need to succeed.

The key to mastering DRF is practice. Start with simple endpoints and gradually add more complex features like authentication, permissions, and advanced filtering. With time and experience, you'll be able to build robust APIs that serve your applications effectively.'''
        }
    ]
    
    # Create the posts
    created_posts = []
    for post_data in sample_posts:
        post, created = Post.objects.get_or_create(
            title=post_data['title'],
            defaults={
                'content': post_data['text'],
                'author': user,
                'published_date': timezone.now()
            }
        )
        if created:
            created_posts.append(post)
            print(f"Created post: {post.title}")
        else:
            print(f"Post already exists: {post.title}")
    
    print(f"\nTotal posts created: {len(created_posts)}")
    print(f"Total posts in database: {Post.objects.count()}")
    
    return created_posts

if __name__ == '__main__':
    create_sample_posts()
